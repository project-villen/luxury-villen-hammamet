# IMMO-LUXURY Website

Luxury real estate website for IMMO-LUXURY.VILLAS-HAMMAMET

## Installation

1. Clone this repository
2. Place all images in `assets/img/` folder
3. Open `index.html` in your browser

## Required Images

- hero-bg.jpg (Hero section background)
- villa-azur.jpg
- villa-saphir.jpg
- villa-diamant.jpg
- villa-mediterraneo.jpg
- villa-oasis.jpg
- villa-riviera.jpg

## Deployment

This website is ready for deployment on Netlify or any other static hosting service.